﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace NewFoodLibraryFINAL
{
	public class Food {
		public double Sugar { get; set; } = 0; // Углеводы
		public double Proteins { get; set; } = 0; // Белки
		public double Calories { get; set; } = 0; // Калории
		public string Foodname { get; set; } = "Pickle"; // Наименование продукта

		public Food() {

		}
		public Food(double sugar, double proteins, double calories, string foodname) {
            Sugar = sugar;
			Proteins = proteins;
			Calories = calories;
			Foodname = foodname;
		}

		public void CreateXmlElem(XDocument xdoc, string filename) {
			XElement xElement = new XElement(Foodname);
			XAttribute oneAttr = new XAttribute("Калории", Calories);
			XAttribute secAttr = new XAttribute("Белки", Proteins);
			XAttribute thrAttr = new XAttribute("Углеводы", Sugar);
			xElement.Add(oneAttr, secAttr, thrAttr);
			xdoc.Root.Add(xElement);
			xdoc.Save(filename);
        }
	}
}
