﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewFoodLibraryFINAL {
    public class FoodCalculate {

        public double SCalories { get; set; } = 0;
        public double SProteins { get; set; } = 0;
        public double SSugar { get; set; } = 0;

        public double NCalories { get; set; } = 0;
        public double NProteins { get; set; } = 0;
        public double NSugar { get; set; } = 0;

        short isHungry { get; set; } = 0;

        public FoodCalculate() {

        }

        public void Calculate(FoodList list) {
            foreach (var item in list.Foods) {
                SCalories += item.Calories;
                SProteins += item.Proteins;
                SSugar += item.Sugar;
            }
        }

        public void Calculate(double cal, double prot, double sug) {
            SCalories += cal;
            SProteins += prot;
            SSugar += sug;
        }

        public string Eaten() {
            if (SCalories < NCalories && SProteins < NProteins && SSugar < NSugar) {
                isHungry = -1;
            } else if(SCalories > NCalories && SProteins > NProteins && SSugar > NSugar) {
                isHungry = 1;
            } else if (SCalories == NCalories && SProteins == NProteins && SSugar == NSugar) {
                isHungry = 10;
            }

            if (isHungry == 0) {
                string message = "Вы совсем ничего не ели сегодня!";
                return message;
            } else if (isHungry == -1) {
                string message = "Вы съели немного меньше, чем обычно!";
                return message;
            } else if (isHungry == 1) {
                string message = "Вы съели немного побольше, чем обычно!";
                return message;
            } else if (isHungry == 10) {
                string message = "Вы насытились!";
                return message;
            }
            return null;
        }

    }
}
