﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace NewFoodLibraryFINAL {
	public class FoodXML {

		public XDocument Xdocument { get; set; }
		public string Filename { get; set; }

		public FoodXML() {
		}

        public FoodXML(string filename) => Filename = filename;

        public void CreateXMLDoc() {
			Xdocument = new XDocument();
			Xdocument.Add(new XElement("Еда"));
			Xdocument.Save(Filename);
		}
		public void CreateXMLDoc(string rootElementName) {
			Xdocument = new XDocument();
			Xdocument.Add(new XElement(rootElementName));
			Xdocument.Save(Filename);
		}
		public void LoadXMLDoc(string filename) {
			Filename = filename;
			Xdocument = XDocument.Load(Filename);
		}
		public void AddXmlElem(XElement xe, XElement xee) {
			xe.Add(xee);
			Xdocument.Save(Filename);
        }
		public void AddXmlElem(XElement xe, XAttribute xa) {
			xe.Add(xa);
			Xdocument.Save(Filename);
		}
	}
}
