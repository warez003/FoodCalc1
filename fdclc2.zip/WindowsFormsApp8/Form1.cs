﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NewFoodLibraryFINAL;
using System.Xml.Linq;
using System.Globalization;

namespace WindowsFormsApp8 {
    public partial class Form1 : Form {

        const string PATH = "foods.xml";
        FoodCalculate calc = new FoodCalculate();
        FoodXML _out = new FoodXML("out.xml");
        FoodList eat = new FoodList();
        FoodList ate = new FoodList();
        IFormatProvider format = new NumberFormatInfo { NumberDecimalSeparator = "." };
        string nameOfEating = null;

        public Form1() {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e) {

            button2.Enabled = false;
            comboBox1.Enabled = false;
            textBox1.Enabled = false;

            eat.Foods = new List<Food> {
                new Food(0, 0, 0, "Вода"),
                new Food(41, Convert.ToDouble("6,6"), 206, "Хлеб_Дарницкий"),
                new Food(0, Convert.ToDouble("18,9"), 187, "Говядина")
            };

            textBox1.Text = $"Калории: {calc.SCalories} Белки: {calc.SProteins} Углеводы: {calc.SSugar}";

            foreach (var item in eat.Foods)
            {
                comboBox1.Items.Add(item.Foodname);
            }

            comboBox1.Text = (string) comboBox1.Items[0];

            comboBox1.TextChanged += ComboBox1_TextChanged;

        }

        private void ComboBox1_TextChanged(object sender, EventArgs e) {
        }

        private void button1_Click(object sender, EventArgs e) {
            if (radioButton1.Checked) {
                label2.Text = radioButton1.Text;
                nameOfEating = label2.Text;
                button2.Enabled = true;
                comboBox1.Enabled = true;
                textBox1.Enabled = true;

                label1.Text = "";

                foreach (var item in eat.Foods) {
                    label1.Text += item.Foodname + "\n" + "Калории: " + item.Calories + "\n" + "Углеводы: " + item.Sugar + "\n" + "Белки: " + item.Proteins + "\n";
                }
            } else if (radioButton2.Checked) {
                label2.Text = radioButton2.Text;
                nameOfEating = label2.Text;
                button2.Enabled = true;
                comboBox1.Enabled = true;
                textBox1.Enabled = true;

                label1.Text = "";

                foreach (var item in eat.Foods)
                {
                    label1.Text += item.Foodname + "\n" + "Калории: " + item.Calories + "\n" + "Углеводы: " + item.Sugar + "\n" + "Белки: " + item.Proteins + "\n";
                }
            } else if (radioButton3.Checked) {
                label2.Text = radioButton3.Text;
                nameOfEating = label2.Text;
                button2.Enabled = true;
                comboBox1.Enabled = true;

                label1.Text = "";

                foreach (var item in eat.Foods)
                {
                    label1.Text += item.Foodname + "\n" + "Калории: " + item.Calories + "\n" + "Углеводы: " + item.Sugar + "\n" + "Белки: " + item.Proteins + "\n";
                }
            }
        }

        private void button2_Click(object sender, EventArgs e) {

            label2.Text = "";

            foreach (var item in eat.Foods)
            {
                if (item.Foodname == comboBox1.Text)
                {
                    ate.Foods.Add(item);
                }
            }

            foreach (var item in ate.Foods)
            {
                label2.Text = item.Foodname + " " + item.Count + "\n";
            }
        }
    }
}
