﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NewFoodLibraryFINAL;
using System.Xml.Linq;
using System.Globalization;
using System.Collections;
using System.IO;

namespace WindowsFormsApp8 {

    public partial class Form1 : Form {
        IFormatProvider format = new NumberFormatInfo { NumberDecimalSeparator = "." };
        FoodList foodList = new FoodList();
        FoodCalculate fc = new FoodCalculate();

        public Form1() {
            InitializeComponent();
            saveFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
        }

        private void Form1_Load(object sender, EventArgs e) {

            foodList.Foods.Add(new Food(0, 23, 500, "Бекон"));
            foodList.Foods.Add(new Food(8.1, 0.9, 36, "Апельсиновый сок"));
            foodList.Foods.Add(new Food(4.3, 3.5, 64, "Солянка домашняя"));
            foodList.Foods.Add(new Food(0.7, 11.9, 215, "Яичница"));
            foodList.Foods.Add(new Food(21.8, 1.5, 95, "Банан"));
            textBox1.Enabled = false;
            listBox1.Enabled = false;
            comboBox1.Items.Add("Завтрак");
            comboBox1.Items.Add("Обед");
            comboBox1.Items.Add("Ужин");
            comboBox1.Items.Add("Перекус");
            button1.AutoSize = true;
            button1.Text = "Сохранить";

            foreach (var item in foodList.Foods) {
                listView1.Items.Add(item.ToLine).Name = item.Foodname;
            }

            comboBox1.SelectedValueChanged += ComboBox1_SelectedValueChanged;
            textBox2.Text = Convert.ToString(2600);
            listView1.ItemMouseHover += ListView1_ItemMouseHover;
            button1.Click += Button1_Click;
        }

        private void Button1_Click(object sender, EventArgs e) {
            if (saveFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            string filename = saveFileDialog1.FileName;
            string bigData = "null";
            bigData = Convert.ToString(comboBox1.SelectedItem) + '\n' + '\n';
            for (int i = 0; i < listBox1.Items.Count; i++) {
                bigData += Convert.ToString(listBox1.Items[i]) + '\n';
            }
            bigData += '\n' + textBox1.Text + " ";
            File.AppendAllText(filename, bigData + '\n');
        }

        private void ComboBox1_SelectedValueChanged(object sender, EventArgs e) {
            if (comboBox1.Text.Length > 0) {
                listBox1.Enabled = true;
            }

            fc.SCalories = 0;
            listBox1.Items.Clear();
            textBox1.Text = $"Ваши калории: {fc.SCalories}!";

        }

        private void ListView1_ItemMouseHover(object sender, ListViewItemMouseHoverEventArgs e) {

            fc.NCalories = Convert.ToDouble(textBox2.Text);

            if (fc.SCalories >= fc.NCalories) {
                textBox1.Text = $"Ваши калории: {fc.SCalories}!";
            } else if (fc.SCalories < fc.NCalories && listBox1.Enabled == true) {
                listBox1.Items.Add(e.Item.Name);
                foreach (var item in foodList.Foods) {
                    for (int i = 0; i < listBox1.Items.Count; i++) {
                        if (Convert.ToString(listBox1.Items[i]) == item.Foodname) {
                            fc.AddCalories(item.Calories);
                            textBox1.Text = Convert.ToString(fc.SCalories);
                        }
                    }
                }
            } else if (listBox1.Enabled == false) {
                textBox1.Text = $"Введите прием пищи (завтрак/обед)";
            }

        }
    }
}
