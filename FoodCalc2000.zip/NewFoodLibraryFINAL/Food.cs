﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace NewFoodLibraryFINAL
{
	public class Food {
		public double Sugar { get; set; } = 0; // Углеводы
		public double Proteins { get; set; } = 0; // Белки
		public double Calories { get; set; } = 0; // Калории
		public string Foodname { get; set; } = "Pickle"; // Наименование продукта
		public int Count { get; set; } = 0;
		public string ToLine => $"{Foodname}: Кал:{Calories}, Бел:{Proteins}, Углев:{Sugar}";

		public Food() {

		}
		public Food(double sugar, double proteins, double calories, string foodname) {
            Sugar = sugar;
			Proteins = proteins;
			Calories = calories;
			Foodname = foodname;
        }
    }
}
