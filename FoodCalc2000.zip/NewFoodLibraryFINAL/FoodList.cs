﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewFoodLibraryFINAL {
    public class FoodList {
        public List<Food> Foods { get; set; }
        public FoodList() {
            Foods = new List<Food>();
        }
    }
}
